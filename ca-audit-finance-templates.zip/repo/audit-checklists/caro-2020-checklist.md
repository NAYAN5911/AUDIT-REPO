# CARO 2020 Checklist (Clause 3)

Entity: ____  FY: ____

| Clause | Subject | Applicable? | Done |
|---|---|---|---|
| 3(i) | PPE and intangible assets, records, physical verification, title deeds, revaluation, benami property | | [ ] |
| 3(ii) | Inventory verification; working-capital limits above Rs. 5 crore, quarterly returns | | [ ] |
| 3(iii) | Investments, guarantees, loans and advances to parties | | [ ] |
| 3(iv) | Sections 185 and 186 compliance | | [ ] |
| 3(v) | Deposits, Sections 73-76 | | [ ] |
| 3(vi) | Cost records | | [ ] |
| 3(vii) | Statutory dues, disputed dues | | [ ] |
| 3(viii) | Unrecorded income disclosed in tax assessments | | [ ] |
| 3(ix) | Defaults in repayment, end use of loans, short/long-term fund diversion | | [ ] |
| 3(x) | IPO/FPO and preferential allotment | | [ ] |
| 3(xi) | Fraud and whistle-blower complaints | | [ ] |
| 3(xii) | Nidhi companies | | [ ] |
| 3(xiii) | Related party transactions, Sections 177 and 188 | | [ ] |
| 3(xiv) | Internal audit system | | [ ] |
| 3(xv) | Non-cash transactions with directors, Section 192 | | [ ] |
| 3(xvi) | RBI registration (NBFC) | | [ ] |
| 3(xvii) | Cash losses | | [ ] |
| 3(xviii) | Resignation of statutory auditors | | [ ] |
| 3(xix) | Material uncertainty on ability to meet liabilities | | [ ] |
| 3(xx) | CSR compliance | | [ ] |
| 3(xxi) | Qualifications in consolidated statements' CARO reports | | [ ] |

Verify thresholds and applicability against the current order text.
