# GST Audit / Reconciliation Checklist

**Taxpayer:** ____  **FY:** ____

- [ ] Registration details, place of business, additional places
- [ ] Turnover per books vs GSTR-1 vs GSTR-3B vs financial statements
- [ ] Output tax: rate-wise bifurcation, exempt/nil/non-GST supplies
- [ ] Credit/debit notes and discounts: GST treatment (Section 15)
- [ ] ITC: GSTR-2B vs books; blocked credits (Section 17(5)); reversals (Rule 42/43)
- [ ] Time limit for ITC (Section 16(4)) and payment to suppliers within 180 days
- [ ] RCM liability and ITC
- [ ] TDS/TCS (GSTR-7/8) reconciliation
- [ ] E-invoicing and e-way bill compliance
- [ ] Interest, late fee and demands; refunds claimed
- [ ] Annual return (GSTR-9) and reconciliation statement (GSTR-9C) where applicable
- [ ] Audit reply: para-wise response, documentary evidence list, legal references
