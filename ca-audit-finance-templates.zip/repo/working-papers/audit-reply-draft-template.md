# Reply to Audit Observation - Template

**To:** [Authority]  **Ref:** [Letter no. and date]  **Taxpayer:** [Name, GSTIN]  **FY:** ____

## Para [No.]: [Short title of observation]

**1. Observation (as per audit report)**
[Summarise the observation and amount involved.]

**2. Facts of the case**
[Neutral, chronological facts with dates and amounts.]

**3. Legal position**
[Relevant section/rule/notification, circulars and case law with citations.]

**4. Submission**
[Why the observation is not sustainable / is accepted, and the quantum, if any.]

**5. Documents enclosed**
- Annexure A: ____
- Annexure B: ____

**6. Prayer**
Kindly drop/modify the observation in Para [No.]

Date: ____  Place: ____   Authorised signatory: ____
