# Audit Planning Memo

**Client:** ____  **FY:** ____  **Prepared by:** ____  **Date:** ____

## 1. Background of entity
Nature of business, locations, key management, group structure.

## 2. Key risks identified
| Area | Risk | Response |
|---|---|---|
| Revenue | | |
| Receivables | | |
| Related parties | | |

## 3. Materiality
- Overall materiality: ____ (basis: ____)
- Performance materiality: ____
- Trivial threshold: ____

## 4. Team and timeline
Team members, visit dates, reporting deadlines.

## 5. Use of experts / other auditors
