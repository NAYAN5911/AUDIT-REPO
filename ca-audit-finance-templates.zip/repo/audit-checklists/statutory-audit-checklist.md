# Statutory Audit Checklist

**Entity:** ____  **FY:** ____  **Engagement partner:** ____

## 1. Acceptance and planning
- [ ] Engagement letter signed (SA 210)
- [ ] Independence and ethics confirmation; Section 141 eligibility checked
- [ ] Previous auditor communication (Section 140 / ICAI code)
- [ ] Understanding of entity, risks and internal controls (SA 315)
- [ ] Materiality and audit plan (SA 320, SA 300)

## 2. Execution
- [ ] Opening balances agreed to prior-year audited accounts
- [ ] Bank confirmations / reconciliations
- [ ] Debtors and creditors confirmations and ageing review
- [ ] Inventory verification and valuation
- [ ] PPE: additions, disposals, depreciation recomputation
- [ ] Borrowings: sanction letters, security, covenants
- [ ] Revenue cut-off and tax compliance (TDS, GST, income tax)
- [ ] Related parties (Section 188) and loans/investments (Section 185/186)
- [ ] Subsequent events (SA 560); going concern (SA 570)

## 3. Completion
- [ ] Management representation letter (SA 580)
- [ ] Written communication with those charged with governance (SA 260)
- [ ] CARO 2020 reporting (see `caro-2020-checklist.md`)
- [ ] Internal financial controls report (Section 143(3)(i))
- [ ] Audit report and UDIN generated
