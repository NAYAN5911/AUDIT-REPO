# Management Representation Letter

*(On the entity's letterhead)*

To,
[Auditor name], Chartered Accountants

Date: ____

Dear Sirs,

This representation letter is provided in connection with your audit of the financial statements of [Entity] for the year ended [date].

We confirm, to the best of our knowledge and belief, that:
1. We have fulfilled our responsibility for the preparation of the financial statements in accordance with the applicable framework.
2. We have provided you with all relevant information and access, and all transactions are recorded in the books.
3. We have disclosed all known actual or suspected fraud and non-compliance with laws.
4. All related parties and related party transactions have been disclosed.
5. All events after the reporting date requiring adjustment or disclosure have been dealt with.
6. We have no plans that may materially alter the carrying value of assets and liabilities.
7. Contingent liabilities and commitments have been fully disclosed.

For [Entity]

Name / Designation: ____   Signature: ____
