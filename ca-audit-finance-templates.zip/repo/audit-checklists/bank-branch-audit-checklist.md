# Bank Branch Audit Checklist

**Branch:** ____  **FY:** ____

## Advances
- [ ] Sanction terms, documentation and security valid
- [ ] Asset classification per IRAC norms (SMA / NPA identification, days past due)
- [ ] Provisioning recomputed as per IRAC norms; check ADV statements against books
- [ ] Interest overdue/unrealised interest treatment
- [ ] Stock/book debt statements and drawing power

## Deposits and cash
- [ ] Cash verification and vault tally
- [ ] Deposit interest provisioning
- [ ] Dormant/inoperative accounts review
- [ ] Suspense and sundry accounts ageing; inter-branch reconciliation

## Other
- [ ] Fixed assets verification
- [ ] Frauds and large-value transactions reporting
- [ ] LFAR points covered
- [ ] Compliance with RBI directions and branch audit report formats
