# How to Use

## Colour conventions in Excel files
- **Blue text:** input cells; overwrite these.
- **Black text:** formulas; do not overwrite.
- **Yellow fill:** cells you must fill (date, eliminations).

## Balance sheet workflow
1. In `balance-sheet/schedule-iii-format.xlsx`, paste ledgers into `TB Mapping`.
2. Type the Schedule III head for each ledger exactly as spelled in the `Balance Sheet` tab.
3. Confirm the TB difference and the final check cell are both zero.

## Consolidation workflow
1. Enter each branch's balances in `branch-consolidation-template.xlsx`.
2. Put inter-branch elimination entries in the yellow column.
3. The difference row must be zero for every column.

## Publishing on GitHub
```
git init
git add .
git commit -m "Initial commit: CA audit and finance templates"
git branch -M main
git remote add origin https://github.com/<your-username>/ca-audit-finance-templates.git
git push -u origin main
```
Create the empty repo on github.com first (no README), then run the commands above.
