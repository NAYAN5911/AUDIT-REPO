# Notes to Accounts - Outline (Schedule III)

## A. Significant accounting policies
- [ ] Basis of preparation (Ind AS / AS, historical cost, going concern)
- [ ] Use of estimates
- [ ] Revenue recognition
- [ ] Property, plant & equipment and depreciation (method, useful lives)
- [ ] Inventories valuation
- [ ] Employee benefits
- [ ] Taxes on income (current and deferred)
- [ ] Provisions, contingent liabilities and assets
- [ ] Foreign currency transactions

## B. Notes to balance sheet
1. Share capital (authorised, issued, subscribed; reconciliation; shareholders above 5%; promoters' holding)
2. Reserves & surplus (movement-wise)
3. Long-term borrowings (secured/unsecured, terms, security)
4. Trade payables (MSME dues; ageing)
5. Other current liabilities / provisions
6. Property, plant & equipment (see `schedules/ppe-schedule.xlsx`)
7. Investments
8. Inventories
9. Trade receivables (ageing; see `schedules/ageing-debtors-creditors.xlsx`)
10. Cash & bank balances
11. Loans and advances / other assets

## C. Notes to profit & loss
- Revenue from operations, other income, cost of materials, employee benefits, finance costs, depreciation, other expenses (auditor's remuneration breakup)

## D. Other disclosures
- [ ] Related party transactions
- [ ] Contingent liabilities and commitments
- [ ] Earnings per share
- [ ] Ratios (as required by Schedule III) with variance explanation above 25%
- [ ] Event after reporting date
- [ ] Previous year figures regrouped
